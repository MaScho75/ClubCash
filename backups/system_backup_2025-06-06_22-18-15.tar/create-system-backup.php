<?php
session_start();

if (!isset($_SESSION['user_authenticated']) || $_SESSION['user_authenticated'] !== true) {
    header('Location: index.php');
    exit();
}

$backupDir = 'backups/';
$backupFile = $backupDir . 'system_backup_' . date('Y-m-d_H-i-s') . '.tar'; 

if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
}   

$command = "tar -cf " . escapeshellarg($backupFile) . " .";
exec($command, $output, $returnValue);

if ($returnValue === 0) {
    echo "Backup erfolgreich erstellt: " . htmlspecialchars($backupFile);
} else {
    echo "Fehler beim Erstellen des Backups.";
}

exit();
?>
